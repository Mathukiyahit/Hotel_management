<?php
$name=$_POST['name'];
$contact=$_POST['contact'];
$adharcard=$_POST['adharcard'];
$cindate=$_POST['cindate'];
$codate=$_POST['codate'];
$adults=$_POST['adults'];
$children=$_POST['children'];
$room=$_POST['room'];
$roomtype=$_POST['roomtype'];


$servername = "localhost";
$username = "root";  
$password = "";  
$databasename = "hotel_data"; 
// Create connection
$conn = new mysqli($servername, $username, $password,$databasename);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
//echo "Connected successfully";


$sql = "INSERT INTO client_data  (name, contact, adharcard, cindate,codate,adults,children,room,roomtype) VALUES ('$name', '$contact', '$adharcard', '$cindate', '$codate', '$adults', '$children', '$room', '$roomtype')";

if (mysqli_query($conn, $sql)) 
{
    header("Location:http://localhost/project/book-now.php");
} 

$conn->close();

?>