<section class="footer">

      <div class="box-container">

         <div class="box">
            <h3>contact info</h3>
            <a href="#"> <i class="fas fa-phone"></i> +91 93132 61452</a>
            <a href="#"> <i class="fas fa-phone"></i> +91 95120 75955</a>
            <a href="#"> <i class="fas fa-phone"></i> +91 282854 36530 (reception no)</a>
            <a href="#"> <i class="fas fa-envelope"></i> aquatichotel001@gmail.com</a>
            <a href="#"> <i class="fas fa-map"></i>ahmdabad gujrat</a>
         </div>

         <div class="box">
            <h3>quick links</h3>
            <a href="home.php"> <i class="fas fa-arrow-right"></i> home</a>
            <a href="about.php"> <i class="fas fa-arrow-right"></i> about</a>
            <a href="service.php"> <i class="fas fa-arrow-right"></i> services</a>
            <a href="room.php"> <i class="fas fa-arrow-right"></i> Room</a>
            <a href="book-now.php"> <i class="fas fa-arrow-right"></i>book now</a>
         </div>

         <div class="box">
            <h3>extra links</h3>
            <a href="#">
               <i class="fas fa-arrow-right"></i>
                  Refund policy
            </a>
         </div>

      </div>

      <div class="share">
         <a href="#" class="fab fa-facebook-f"></a>
         <a href="#" class="fab fa-instagram"></a>
         <a href="#" class="fab fa-twitter"></a>
      </div>

      <div class="credit">&copy; copyright @ 2023 by <span>Kevin & Heet</span></div>

   </section>