<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title></title>
</head>
<body>

<?php

$adharcard=$_POST['adharcard'];

$servername = "localhost";
$username = "root";  
$password = "";  
$databasename = "hotel_data"; 
// Create connection
$conn = new mysqli($servername, $username, $password,$databasename);
// Check connection
if ($conn->connect_error) 
{
    die("Connection failed: " . $conn->connect_error);
}

    $sql="select * from client_data where adharcard='$adharcard'";

    $result=mysqli_query($conn, $sql);

    
    while($row=$result->fetch_row())
    {


    echo "<table border='2' align='center'>
    <tr>Name:</td>".$row['0']."</td></tr><br>
    <tr>Your-contect:</td>".$row['1']."</td></tr><br>
    <tr>Your-adharcard:</td>".$row['2']."</td></tr><br>
    <tr>Check-in-date:</td>".$row['3']."</td></tr><br>
    <tr>Check-out-date:</td>".$row['4']."</td></tr><br>
    <tr>Adults:</td>".$row['5']."</td></tr><br>
    <tr>Children:</td>".$row['6']."</td></tr><br>
    <tr>Room:</td>".$row['7']."</td></tr><br>
    <tr>Room-type:</td>".$row['8']."</td></tr><br></table>";
  
    }


?>

</body>
</html>

 