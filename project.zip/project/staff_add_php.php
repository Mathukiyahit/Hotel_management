<?php

$name=$_POST['name'];
$contact=$_POST['contact'];
$salary=$_POST['salary'];
$category=$_POST['category'];
$address=$_POST['address'];

$conn=new mysqli("localhost","root","","hotel_data");

if($conn->connect_error)
{
      die("connection failed ".$conn->connect_error);

}

$sql="INSERT into staff_data values('$name','$contact','$salary','$category','$address')";

$result=mysqli_query($conn,$sql);

if($result)
{
	echo '<script>alert("Welcome to Geeks for Geeks")</script>'; 
	header('Location:http://localhost/project/staff_add.html');
}
else 
{
     header('Location:http://localhost/project/staff_add.html');
}

?>