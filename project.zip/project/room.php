<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Hotel Management</title>

	 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
 
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.css">
   
       <link  rel="stylesheet" href="css/style1.css">
</head>
<body>

	<!--menubar----------------------------->
<?php
include("header.php");
?>

 <!-- room -->

   <section class="room" id="room">

      <h1 class="heading" style="margin-top: 60px;">our room</h1>

      <div class="swiper room-slider">

         <div class="swiper-wrapper">

            <div class="swiper-slide slide">
               <div class="image">
                  <span class="price">Rs.3500/night</span>
                  <img src="image/room-1.jpg" alt="">
                  <a href="book-now.php" class="fas fa-shopping-cart"></a>
               </div>
               <div class="content">
                  <h3>Family-room</h3>
                  <div class="stars">
                     <i class="fas fa-star"></i>
                     <i class="fas fa-star"></i>
                     <i class="fas fa-star"></i>
                     <i class="fas fa-star"></i>
                     <i class="fas fa-star-half-alt"></i>
                  </div>
                  <a href="book-now.php" class="btn">book now</a>
               </div>
            </div>

            <div class="swiper-slide slide">
               <div class="image">
                  <span class="price">Rs.3500/night</span>
                  <img src="image/room-2.jpg" alt="">
                  <a href="book-now.php" class="fas fa-shopping-cart"></a>
               </div>
               <div class="content">
                  <h3>Business-room</h3>
                  <div class="stars">
                     <i class="fas fa-star"></i>
                     <i class="fas fa-star"></i>
                     <i class="fas fa-star"></i>
                     <i class="fas fa-star"></i>
                     <i class="fas fa-star-half-alt"></i>
                  </div>
                  <a href="book-now.php" class="btn">book now</a>
               </div>
            </div>

            <div class="swiper-slide slide">
               <div class="image">
                  <span class="price">Rs.5000/night</span>
                  <img src="image/room-3.jpg" alt="">
                  <a href="book-now.php" class="fas fa-shopping-cart"></a>
               </div>
               <div class="content">
                  <h3>small family-room</h3>
                  <div class="stars">
                     <i class="fas fa-star"></i>
                     <i class="fas fa-star"></i>
                     <i class="fas fa-star"></i>
                     <i class="fas fa-star"></i>
                     <i class="fas fa-star-half-alt"></i>
                  </div>
                  <a href="book-now.php" class="btn">book now</a>
               </div>
            </div>

            <div class="swiper-slide slide">
               <div class="image">
                  <span class="price">Rs.4500/night</span>
                  <img src="image/room-4.jpg" alt="">
                  <a href="book-now.php" class="fas fa-shopping-cart"></a>
               </div>
               <div class="content">
                  <h3>couple-room</h3>
                  <div class="stars">
                     <i class="fas fa-star"></i>
                     <i class="fas fa-star"></i>
                     <i class="fas fa-star"></i>
                     <i class="fas fa-star"></i>
                     <i class="fas fa-star-half-alt"></i>
                  </div>
                  <a href="book-now.php" class="btn">book now</a>
               </div>
            </div>

            <div class="swiper-slide slide">
               <div class="image">
                  <span class="price">Rs.5000/night</span>
                  <img src="image/room-5.jpg" alt="">
                  <a href="book-now.php" class="fas fa-shopping-cart"></a>
               </div>
               <div class="content">
                  <h3>couple-room</h3>
                  <div class="stars">
                     <i class="fas fa-star"></i>
                     <i class="fas fa-star"></i>
                     <i class="fas fa-star"></i>
                     <i class="fas fa-star"></i>
                     <i class="fas fa-star-half-alt"></i>
                  </div>
                  <a href="book-now.php" class="btn">book now</a>
               </div>
            </div>

            <div class="swiper-slide slide">
               <div class="image">
                  <span class="price">Rs.4500/night</span>
                  <img src="image/room-6.jpg" alt="">
                  <a href="book-now.php" class="fas fa-shopping-cart"></a>
               </div>
               <div class="content">
                  <h3>family-room</h3>
                  <div class="stars">
                     <i class="fas fa-star"></i>
                     <i class="fas fa-star"></i>
                     <i class="fas fa-star"></i>
                     <i class="fas fa-star"></i>
                     <i class="fas fa-star-half-alt"></i>
                  </div>
                  <a href="book-now.php" class="btn">book now</a>
               </div>
            </div>

         </div>

         <div class="swiper-pagination"></div>

      </div>

   </section>



 <!--footer----------------------------->

<?php
include("footer.php");
?>
   
<script src="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.js"></script>
 <script src="js/script.js"></script>

</body>
</html>