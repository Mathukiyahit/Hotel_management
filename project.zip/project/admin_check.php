<?php
if($_SERVER["REQUEST_METHOD"]=="POST")
{
	$username=$_POST["username"];
	$password=$_POST["password"];
}


$con=mysqli_connect('localhost','root','','hotel_data');
if($con==false)
{
	die("Connection error");
}


 $sql="select * from admin_data where username='$username' and password='$password'";
 
$result=mysqli_query($con, $sql);

if(mysqli_num_rows($result)==1) 
{

	header('Location:http://localhost/project/dashbord.php');  
} 
else 
{
   echo"<script>alert('plese enter currect values')</script>";
   header('Location:http://localhost/project/admin.html');
}

?>