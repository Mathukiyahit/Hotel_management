<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Hotel Management</title>

	   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
 
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.css">
   
       <link  rel="stylesheet" href="css/style1.css">

</head>
<body>

	<!--menubar----------------------------->
<?php
include("header.php");
?>

<!-- services -->

   <section class="services">

   	<h1 class="heading" style="margin-top:60px">Services</h1>

      <div class="box-container" style="margin-top: 60px;">

         <div class="box">
            <img src="image/service1.png" alt="">
            <h3>swimming pool</h3>
         </div>

         <div class="box">
            <img src="image/service2.png" alt="">
            <h3>food & drink</h3>
         </div>

         <div class="box">
            <img src="image/service3.png" alt="">
            <h3>restaurant</h3>
         </div>

         <div class="box">
            <img src="image/service4.png" alt="">
            <h3>fitness</h3>
         </div>

         <div class="box">
            <img src="image/service5.png" alt="">
            <h3>beauty spa</h3>
         </div>

         <div class="box">
            <img src="image/service6.png" alt="">
            <h3>resort beach</h3>
         </div>

      </div>

   </section>


   <!-- faq -->

   <section class="faqs" id="faq">

      <h1 class="heading">frequently asked questions</h1>

      <div class="row">

         <div class="image">
            <img src="image/FAQs.gif" alt="">
         </div>

         <div class="content">

            <div class="box active">
               <h3>what are payment methods?</h3>
               <p>Online pay  or cash</p>
            </div>

            <div class="box">
               <h3>Are pet allowed at your facilities?</h3>
               <p>The pet are not allowed to enter the faclities.</p>
            </div>

            <div class="box">
               <h3>Do you have parking available?</h3>
               <p>The parking has available in hotel.</p>
            </div>

            <div class="box">
               <h3>is there wi-fi in every room?</h3>
               <p>High speed internet is offered for free throughout the hotel.</p>
            </div>

            <div class="box">
               <h3>can i smoke in the establishment?</h3>
               <p>Noo. our Hotel is 100% non-smoking establishment.</p>
            </div>

         </div>

      </div>

   </section>

   <!----- review--------------------------->

<section class="review" id="review" style="margin-bottom: 80px;">

      <div class="swiper review-slider">
        <div style="position: absolute; top: 50%;left: 50%; transform: translate(-50%,-50%); width: 400px;">

         <h1 style="font-size: 30px; text-align: center;text-transform: uppercase;margin: 40px 0;">your review</h1>

         <form method="post" action="review_send.php">

            <p style="font-size: 15px;margin: 15px 0;">Name</p>
            <input type="text" name="name" placeholder="Yourname" style="font-size: 16px;padding: 10px 10px;width: 100%;border: 0; border-radius: 5px;outline: none;">

            <p style="font-size: 15px;margin: 15px 0;">Contact</p>
            <input type="text" name="contact" placeholder="Contact" style="font-size: 16px;padding: 10px 10px;width: 100%;border: 0; border-radius: 5px;outline: none;">

            <p style="font-size: 15px;margin: 15px 0;">E-mail</p>
            <input type="email" name="email" placeholder="E-mail" style="font-size: 16px;padding: 10px 10px;width: 100%;border: 0; border-radius: 5px;outline: none;">

            <p style="font-size:15px;margin: 15px 0;">Message</p>
            <input type="text" name="message" placeholder="Message" style="font-size: 16px;padding: 10px 10px;width: 100%;border: 0; border-radius: 5px;outline: none;">

            <button type="submit" style="font-size: 18px;font-weight: bold; margin: 20px 0; padding: 10px 15px;width: 50%;border: 0;border-radius: 5px;background-color: #fff;">Submit</button>

         </form>
      </div>
      </div>

           

   </section>

   <!--footer----------------------------->

<?php
include("footer.php");
?>

<script src="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.js"></script>
    <script src="js/script.js"></script>

</body>
</html>