<!--menubar----------------------------->
<header class="header">

	<a href="#" class="logo"> <i class="fas fa-hotel"></i> hotel </a>

<nav class="navbar">
	 <a href="home.php">Home</a>
	 <a href="about.php">About</a>
	 <a href="service.php">Service</a>
	 <a href="room.php">Rooms</a>
     <a href="book-now.php" class="btn">Book-now</a>	
</nav>
 <div id="menu-btn" class="fas fa-bars"></div>
</header>