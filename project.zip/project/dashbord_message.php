<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<!-- Boxicons -->
	<link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
	<!-- My CSS -->
	<link rel="stylesheet" href="css/dashbord_css.css">

	<title>AdminHub</title>
</head>
<body>


	<!-- SIDEBAR -->
	<section id="sidebar">
		<a href="#" class="brand">
			<i class='bx bxs-smile'></i>
			<span class="text">AdminHub</span>
		</a>
		<ul class="side-menu top">
			<li class="active">
				<a href="dashbord.php">
					<i class='bx bxs-dashboard' ></i>
					<span class="text">admin</span>
				</a>
			</li>
			<li>
				<a href="dashbord_staff.php">
					<i class='bx bxs-shopping-bag-alt' ></i>
					<span class="text">staff</span>
				</a>
			</li>
			<li>
				<a href="dashbord_client.php">
					<i class='bx bxs-doughnut-chart' ></i>
					<span class="text">client</span>
				</a>
			</li>
			<li>
				<a href="dashbord_message.php">
					<i class='bx bxs-group' ></i>
					<span class="text">message</span>
				</a>
			</li>
		</ul>
		<ul class="side-menu">
			<li>
				<a href="admin.html" class="logout">
					<i class='bx bxs-log-out-circle' ></i>
					 <span class="text">Logout</span>
				</a>
			</li>
		</ul>
	</section>
	<!-- SIDEBAR -->



	<!-- CONTENT -->
	<section id="content">

		<!-- MAIN -->
		<main>
			<div class="head-title">
				<div class="left">
				</div>
				<a href="#" class="btn-download">
					<i class='bx bxs-cloud-download' ></i>
					<span class="text">Download PDF</span>
				</a>
			</div>

			<ul class="box-info">
				<li>
					<i></i>
					<span class="text">
						<h3>100</h3>
						<p>client</p>
					</span>
				</li>
				<li>
					<i></i>
					<span class="text">
						<h3>20</h3>
						<p>staff</p>
					</span>
				</li>
				<li>
					<i></i>
					<span class="text">
						<h3>387</h3>
						<p>message</p>
					</span>
				</li>
			</ul>


			<div class="table-data">
				<div class="order">
					<div class="head">
						<h3>Review</h3>
						<i class='bx bx-search' ></i>
						<i class='bx bx-filter' ></i>
					</div>
					<table>
						<thead>
							<tr>
								<th>Name</th>
								<th>Contect</th>
								<th>Email</th>
								<th>Message</th>
								
							</tr>
						</thead>

						<tbody>
							<?php
                     
                           $conn=new mysqli("localhost","root","","hotel_data");

                           if($conn->connect_error)
                           {
                           	die("connection failed ".$conn->connect_error);

                           }

                           $sql="SELECT * FROM review_data";
                           $result=$conn->query($sql);

                           if(!$result)
                           {
                           	die("invalid query".$conn->error);
                           }

                           while($row=$result->fetch_assoc())
                           {
                                      echo"<tr>

                                      <td>".$row['name']."</td>
                                      <td>".$row['contact']."</td>
                                      <td>".$row['email']."</td>
                                      <td>".$row['message']."</td>
								
							          </tr>";

                           }
							
							?>
						</tbody>

					</table>
				</div>
			</div>
		</main>
		<!-- MAIN -->
	</section>
	<!-- CONTENT -->
	

	<script src="dashbord_script.js"></script>
</body>
</html>