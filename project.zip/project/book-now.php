<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Hotel Management</title>

	 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
 
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.css">
   
       <link  rel="stylesheet" href="css/style1.css">
</head>
<body>

	<!--menubar----------------------------->
<?php
include("header.php");
?>


<!-- book-now -->
<section class="reservation" id="reservation">

      <h1 class="heading" style="margin-top: 60px;">book now</h1>

      <form action="submit_data.php" method="post">

         <div class="container">

            <div class="box">
               <p>name <span>*</span></p>
               <input type="text" class="input" placeholder="Your Name" name="name">
            </div>

            <div class="box">
               <p>contact <span>*</span></p>
               <input type="text" class="input" placeholder="mobile number" name="contact">
            </div>

             <div class="box">
               <p>adharcard no <span>*</span></p>
               <input type="text" class="input" placeholder="adharcard no" name="adharcard">
            </div>

            <div class="box">
               <p>check in <span>*</span></p>
               <input type="date" class="input" name="cindate" pattern="\d{4}-\d{2}-\d{2}">
            </div>

            <div class="box">
               <p>check out <span>*</span></p>
               <input type="date" class="input" name="codate" pattern="\d{4}-\d{2}-\d{2}">
            </div>

            <div class="box">
               <p>adults <span>*</span></p>
               <select name="adults" class="input" name="adults">
                  <option value="1">1 adults</option>
                  <option value="2">2 adults</option>
                  <option value="3">3 adults</option>
                  <option value="4">4 adults</option>
                  <option value="5">5 adults</option>
                  <option value="6">6 adults</option>
               </select>
            </div>

            <div class="box">
               <p>children <span>*</span></p>
               <select class="input" name="children">
                  <option value="1">1 child</option>
                  <option value="2">2 child</option>
                  <option value="3">3 child</option>
                  <option value="4">4 child</option>
                  <option value="5">5 child</option>
                  <option value="6">6 child</option>
               </select>
            </div>

            <div class="box">
               <p>rooms <span>*</span></p>
               <select class="input" name="room">
                  <option value="1">1 rooms</option>
                  <option value="2">2 rooms</option>
                  <option value="3">3 rooms</option>
                  <option value="4">4 rooms</option>
                  <option value="5">5 rooms</option>
                  <option value="6">6 rooms</option>
               </select>
            </div>

            <div class="box">
               <p>room type <span>*</span></p>
               <select class="input" name="roomtype">
                  <option value="exclusive rooms">exclusive rooms</option>
                  <option value="family rooms">family rooms</option>
                  <option value="daily rooms">daily rooms</option>
                  <option value="panoramic rooms">panoramic rooms</option>
               </select>
            </div>
   
         </div>

         <input type="submit" value="Book-now" class="btn" onclick="onsub()">
         <a  href="client_recept.html" value="check my room" class="btn">check my room</a>

      </form>

   </section>


 <!--footer----------------------------->

<?php
include("footer.php");
?>
   
<script src="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.js"></script>
 <script src="js/script.js"></script>

</body>
</html>