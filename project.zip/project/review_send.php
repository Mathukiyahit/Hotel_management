<?php
$name=$_POST['name'];
$contact=$_POST['contact'];
$email=$_POST['email'];
$message=$_POST['message'];


$servername = "localhost";
$username = "root";  
$password = "";  
$databasename = "hotel_data"; 
// Create connection
$conn = new mysqli($servername, $username, $password,$databasename);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
//echo "Connected successfully";


$sql = "INSERT INTO review_data (name, contact, email,message) VALUES ('$name', '$contact', '$email', '$message')";

if (mysqli_query($conn, $sql)) 
{
    header("Location:http://localhost/project/service.html");
} 

$conn->close();

?>